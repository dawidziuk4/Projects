﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pikselator.Models
{
    class ParametersOfPixelation
    {
        public int NumberOfThreads { get; set; }
        public PixelationLibrary pixelationLibrary {get; set;}

    }
}
