#include <iostream>
#include <Windows.h>

using namespace std;

extern "C" int _stdcall PixelateASM();

int main()
{

	return 0;
}